-- Users table, tracks user info and roles
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  role TEXT NOT NULL CHECK (role IN ('student', 'employer', 'admin')),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Certificates table, stores certificate metadata
CREATE TABLE IF NOT EXISTS certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  certificate_number TEXT UNIQUE NOT NULL,
  student_name TEXT NOT NULL,
  degree TEXT NOT NULL,
  issue_date DATE NOT NULL,
  marks TEXT NOT NULL,
  institution TEXT,
  status TEXT NOT NULL CHECK (status IN ('pending', 'verified', 'rejected')) DEFAULT 'pending',
  verification_result TEXT NOT NULL CHECK (verification_result IN ('valid', 'fake', 'suspicious', 'pending')) DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_certificates_student_id ON certificates(student_id);
CREATE INDEX IF NOT EXISTS idx_certificates_certificate_number ON certificates(certificate_number);

-- Verification logs table for recording verification attempts
CREATE TABLE IF NOT EXISTS verificationlogs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employer_id UUID REFERENCES users(id) ON DELETE SET NULL,
  certificate_id UUID REFERENCES certificates(id) ON DELETE SET NULL,
  result TEXT NOT NULL CHECK (result IN ('valid', 'fake', 'suspicious', 'not_found')),
  confidence_score NUMERIC CHECK (confidence_score >= 0 AND confidence_score <= 100),
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_verificationlogs_employer_id ON verificationlogs(employer_id);
CREATE INDEX IF NOT EXISTS idx_verificationlogs_certificate_id ON verificationlogs(certificate_id);

-- Blacklist table to record fraudulent users or certificates
CREATE TABLE IF NOT EXISTS blacklist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_id UUID NOT NULL, -- Could refer to user ID or certificate ID
  reason TEXT NOT NULL,
  comments TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_blacklist_reference_id ON blacklist(reference_id);
