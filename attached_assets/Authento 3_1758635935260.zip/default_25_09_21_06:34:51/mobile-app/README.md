# AUTHENTO Mobile App

![AUTHENTO Mobile](https://img.shields.io/badge/AUTHENTO-Mobile%20App-blue)

## 🎯 Project Overview

AUTHENTO Mobile is a cross-platform React Native application built using Expo and TypeScript. It provides access to the AUTHENTO certificate verification backend services to users on their iOS and Android devices.

The app enables users to:
- Authenticate securely via Supabase Auth
- Verify academic certificates using OCR extracted data input
- View verification logs and statistics
- Manage their profile information

**Note:** OCR integration and blockchain features are currently under development and will be integrated in future releases.

---

## 🏗️ Architecture & Technology Stack

- **Framework:** React Native with Expo managed workflow
- **Language:** TypeScript
- **State Management:** React hooks and context (minimal)
- **Navigation:** React Navigation (Stack navigator)
- **Backend:** Supabase (Auth, Database, Edge Functions)
- **Networking:** Supabase JS client and Axios for REST API calls
- **UI:** React Native Paper, Linear Gradient, SafeAreaContext

---

## 🚀 Getting Started

### Prerequisites

- Node.js (>= 16 recommended)
- Yarn or npm
- Expo CLI (`npm install -g expo-cli`)
- An Android/iOS emulator or physical device with Expo Go installed
- A Supabase project URL and anon/public key (from AUTHENTO backend)

### Installation

1. **Clone the repository**

