import axios from "axios";
import Constants from "expo-constants";
import type { OCRData, VerificationResult, VerificationStats } from "../types";

const SUPABASE_URL = Constants.manifest?.extra?.SUPABASE_URL || process.env.SUPABASE_URL || "";
const BASE_FUNCTIONS_URL = SUPABASE_URL + "/functions/v1";

export async function verifyCertificate(
  token: string,
  ocrData: OCRData
): Promise<VerificationResult> {
  try {
    const response = await axios.post(
      BASE_FUNCTIONS_URL + "/verify",
      ocrData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );
    return response.data;
  } catch (error: any) {
    if (error.response?.data) {
      throw new Error(error.response.data.error || "Verification failed");
    }
    throw new Error(error.message || "Verification failed");
  }
}

export async function getVerificationStats(token: string): Promise<VerificationStats> {
  try {
    const response = await axios.get(
      BASE_FUNCTIONS_URL + "/verification-stats",
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );
    return response.data;
  } catch (error: any) {
    if (error.response?.data) {
      throw new Error(error.response.data.error || "Failed to fetch stats");
    }
    throw new Error(error.message || "Failed to fetch stats");
  }
}
