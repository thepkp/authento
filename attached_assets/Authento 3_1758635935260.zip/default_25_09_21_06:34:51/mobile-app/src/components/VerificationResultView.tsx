import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import type { VerificationResult, FieldComparisonDetail } from "../types";

interface VerificationResultViewProps {
  result: VerificationResult;
}

const VerificationResultView: React.FC<VerificationResultViewProps> = ({ result }) => {
  const { verdict, details, confidence_score, timestamp } = result;

  const renderVerdictColor = () => {
    switch (verdict) {
      case "VALID":
        return "#16a34a"; // green
      case "SUSPICIOUS":
        return "#ca8a04"; // amber
      case "MISMATCH_FOUND":
        return "#dc2626"; // red
      case "NOT_FOUND":
        return "#6b7280"; // gray
      default:
        return "#374151";
    }
  };

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={[styles.title, { color: renderVerdictColor() }]}>
        Verdict: {verdict.replace(/_/g, " ")}
      </Text>

      {typeof confidence_score === "number" && (
        <Text style={styles.confidence}>Confidence Score: {confidence_score.toFixed(2)}%</Text>
      )}

      <Text style={styles.timestamp}>Timestamp: {new Date(timestamp).toLocaleString()}</Text>

      <Text style={styles.sectionTitle}>Field Comparison Details:</Text>
      {details.length === 0 ? (
        <Text style={styles.noDetails}>No comparison details available.</Text>
      ) : (
        details.map((detail: FieldComparisonDetail, idx: number) => (
          <View key={idx} style={styles.detailRow}>
            <Text style={styles.fieldName}>{detail.field}</Text>
            <Text
              style={[
                styles.fieldStatus,
                detail.status === "MATCH"
                  ? styles.statusMatch
                  : detail.status === "MISMATCH"
                  ? styles.statusMismatch
                  : styles.statusMissing
              ]}
            >
              {detail.status}
            </Text>
            {detail.status !== "MATCH" && (
              <View style={styles.mismatchInfo}>
                <Text style={styles.mismatchText}>Expected: {detail.expected ?? "N/A"}</Text>
                <Text style={styles.mismatchText}>Found: {detail.found ?? "N/A"}</Text>
              </View>
            )}
          </View>
        ))
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fef3c7",
    padding: 16,
    borderRadius: 8,
    marginVertical: 12,
    maxHeight: 420
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 8
  },
  confidence: {
    fontSize: 16,
    marginBottom: 4,
    fontWeight: "600"
  },
  timestamp: {
    fontSize: 13,
    color: "#6b7280",
    marginBottom: 12
  },
  sectionTitle: {
    fontWeight: "700",
    fontSize: 16,
    marginBottom: 6,
    color: "#92400e"
  },
  noDetails: {
    fontStyle: "italic",
    color: "#92400e"
  },
  detailRow: {
    backgroundColor: "#fff7ed",
    padding: 10,
    borderRadius: 6,
    marginBottom: 8
  },
  fieldName: {
    fontWeight: "600",
    fontSize: 15,
    marginBottom: 4,
    color: "#78350f"
  },
  fieldStatus: {
    fontWeight: "700",
    marginBottom: 4
  },
  statusMatch: {
    color: "#16a34a"
  },
  statusMismatch: {
    color: "#dc2626"
  },
  statusMissing: {
    color: "#9ca3af"
  },
  mismatchInfo: {
    marginLeft: 8
  },
  mismatchText: {
    fontSize: 13,
    color: "#b45309"
  }
});

export default VerificationResultView;
