import React, { useState, useEffect } from "react";
import {
  View,
  TextInput,
  StyleSheet,
  Text,
  ScrollView,
  KeyboardAvoidingView,
  Platform
} from "react-native";

interface CertificateFormProps {
  onChange: (data: {
    name: string;
    roll_number: string;
    marks: string;
    degree?: string;
    issue_date?: string;
    institution?: string;
  }) => void;
  defaultValues?: Partial<{
    name: string;
    roll_number: string;
    marks: string;
    degree: string;
    issue_date: string;
    institution: string;
  }>;
  errors?: Partial<Record<string, string>>;
}

const CertificateForm: React.FC<CertificateFormProps> = ({
  onChange,
  defaultValues = {},
  errors = {}
}) => {
  const [name, setName] = useState(defaultValues.name || "");
  const [rollNumber, setRollNumber] = useState(defaultValues.roll_number || "");
  const [marks, setMarks] = useState(defaultValues.marks || "");
  const [degree, setDegree] = useState(defaultValues.degree || "");
  const [issueDate, setIssueDate] = useState(defaultValues.issue_date || "");
  const [institution, setInstitution] = useState(defaultValues.institution || "");

  // Update parent on any change
  useEffect(() => {
    onChange({
      name,
      roll_number: rollNumber,
      marks,
      degree: degree.trim() === "" ? undefined : degree,
      issue_date: issueDate.trim() === "" ? undefined : issueDate,
      institution: institution.trim() === "" ? undefined : institution
    });
  }, [name, rollNumber, marks, degree, issueDate, institution]);

  return (
    <KeyboardAvoidingView
      behavior={Platform.select({ ios: "padding", android: undefined })}
      style={{ flex: 1 }}
    >
      <ScrollView
        style={styles.container}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Name *</Text>
          <TextInput
            placeholder="Full Name"
            value={name}
            onChangeText={setName}
            style={[styles.input, errors.name && styles.inputError]}
            accessibilityLabel="Name input"
            autoCapitalize="words"
          />
          {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Roll Number *</Text>
          <TextInput
            placeholder="Certificate Number / Roll Number"
            value={rollNumber}
            onChangeText={setRollNumber}
            style={[styles.input, errors.roll_number && styles.inputError]}
            autoCapitalize="characters"
            accessibilityLabel="Roll number input"
          />
          {errors.roll_number && <Text style={styles.errorText}>{errors.roll_number}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Marks *</Text>
          <TextInput
            placeholder="Marks / Percentage"
            value={marks}
            onChangeText={setMarks}
            style={[styles.input, errors.marks && styles.inputError]}
            accessibilityLabel="Marks input"
            keyboardType="default"
          />
          {errors.marks && <Text style={styles.errorText}>{errors.marks}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Degree</Text>
          <TextInput
            placeholder="Degree (optional)"
            value={degree}
            onChangeText={setDegree}
            style={styles.input}
            accessibilityLabel="Degree input"
            autoCapitalize="words"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Issue Date</Text>
          <TextInput
            placeholder="YYYY-MM-DD (optional)"
            value={issueDate}
            onChangeText={setIssueDate}
            style={[styles.input, errors.issue_date && styles.inputError]}
            accessibilityLabel="Issue date input"
            keyboardType="numbers-and-punctuation"
          />
          {errors.issue_date && <Text style={styles.errorText}>{errors.issue_date}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Institution</Text>
          <TextInput
            placeholder="Institution (optional)"
            value={institution}
            onChangeText={setInstitution}
            style={styles.input}
            accessibilityLabel="Institution input"
            autoCapitalize="words"
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#fff",
    flex: 1
  },
  inputGroup: {
    marginBottom: 14
  },
  label: {
    fontWeight: "600",
    marginBottom: 6,
    color: "#1f2937"
  },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    color: "#1f2937",
    backgroundColor: "#f9fafb"
  },
  inputError: {
    borderColor: "#dc2626",
    backgroundColor: "#fee2e2"
  },
  errorText: {
    color: "#dc2626",
    fontSize: 13,
    marginTop: 4
  }
});

export default CertificateForm;
