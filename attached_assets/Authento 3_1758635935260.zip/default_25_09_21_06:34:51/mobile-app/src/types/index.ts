export interface OCRData {
  name: string;
  roll_number: string;
  marks: string;
  degree?: string;
  issue_date?: string;
  institution?: string;
}

export interface FieldComparisonDetail {
  field: string;
  status: "MATCH" | "MISMATCH" | "MISSING";
  expected?: string;
  found?: string;
}

export interface VerificationResult {
  verdict: "VALID" | "MISMATCH_FOUND" | "NOT_FOUND" | "SUSPICIOUS";
  details: FieldComparisonDetail[];
  confidence_score?: number;
  timestamp: string;
}

export interface User {
  id: string;
  email: string;
  name?: string;
  role?: "student" | "employer" | "admin";
  is_active?: boolean;
  created_at?: string;
}

export interface VerificationLog {
  id: string;
  certificate_number: string;
  result: string;
  timestamp: string;
  confidence_score?: number;
}

export interface VerificationStats {
  total_verifications: number;
  valid_count: number;
  fake_count: number;
  suspicious_count: number;
  not_found_count: number;
  success_rate: number | string;
  recent_verifications: VerificationLog[];
  daily_stats: Array<{
    date: string;
    total: number;
    valid: number;
    fake: number;
    suspicious: number;
  }>;
}
