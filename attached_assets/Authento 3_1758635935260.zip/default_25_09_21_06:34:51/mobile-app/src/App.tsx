import React, { useEffect, useState } from "react";
import { StatusBar, View, ActivityIndicator, StyleSheet } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { SupabaseClient, createClient, Session, User } from "@supabase/supabase-js";

import LoginScreen from "./screens/LoginScreen";
import VerifyCertificateScreen from "./screens/VerifyCertificateScreen";
import VerificationLogsScreen from "./screens/VerificationLogsScreen";
import UserProfileScreen from "./screens/UserProfileScreen";

import { supabase } from "./utils/supabaseClient";

export type RootStackParamList = {
  Login: undefined;
  VerifyCertificate: undefined;
  VerificationLogs: undefined;
  UserProfile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    // Check initial session
    const currentSession = supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
    });

    // Listen for auth changes (login/logout)
    const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => {
      subscription?.subscription.unsubscribe();
    };
  }, []);

  if (session === null) {
    // Loading state while checking session
    return (
      <SafeAreaProvider>
        <SafeAreaView style={styles.centered}>
          <ActivityIndicator size="large" color="#1f2937" />
        </SafeAreaView>
      </SafeAreaProvider>
    );
  }

  const user = session?.user ?? null;

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: true }}>
          {!user ? (
            <Stack.Screen
              name="Login"
              component={LoginScreen}
              options={{ title: "AUTHENTO - Login" }}
            />
          ) : (
            <>
              <Stack.Screen
                name="VerifyCertificate"
                component={VerifyCertificateScreen}
                options={{ title: "Verify Certificate" }}
              />
              <Stack.Screen
                name="VerificationLogs"
                component={VerificationLogsScreen}
                options={{ title: "Verification Logs" }}
              />
              <Stack.Screen
                name="UserProfile"
                component={UserProfileScreen}
                options={{ title: "User Profile" }}
              />
            </>
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  centered: { flex: 1, justifyContent: "center", alignItems: "center" }
});
