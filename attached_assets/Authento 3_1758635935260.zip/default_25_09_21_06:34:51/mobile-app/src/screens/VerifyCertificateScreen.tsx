import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView
} from "react-native";
import { supabase } from "../utils/supabaseClient";
import CertificateForm from "../components/CertificateForm";
import VerificationResultView from "../components/VerificationResultView";
import type { OCRData, VerificationResult } from "../types";

const initialFormData: OCRData = {
  name: "",
  roll_number: "",
  marks: ""
};

const VerifyCertificateScreen: React.FC = () => {
  const [formData, setFormData] = useState<OCRData>(initialFormData);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const validateInputs = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) errors.name = "Name is required";
    if (!formData.roll_number.trim()) errors.roll_number = "Roll number is required";
    if (!formData.marks.trim()) errors.marks = "Marks are required";

    // Optional: Validate issue_date if provided
    if (formData.issue_date && !/^\d{4}-\d{2}-\d{2}$/.test(formData.issue_date)) {
      errors.issue_date = "Issue date must be in YYYY-MM-DD format";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateInputs()) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;

      if (!token) {
        setError("You must be logged in to verify certificates.");
        setLoading(false);
        return;
      }

      const res = await fetch(
        `${process.env.EXPO_PUBLIC_SUPABASE_URL || supabaseUrl()}/functions/v1/verify`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify(formData)
        }
      );

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error ?? "Verification failed");
      }

      const data: VerificationResult = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || String(err));
    } finally {
      setLoading(false);
    }
  };

  // Helper to access env or fallback
  const supabaseUrl = () => {
    return "https://your-supabase-url.supabase.co"; // Replace with your Supabase URL or env-based
  };

  return (
    <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <CertificateForm
        onChange={setFormData}
        defaultValues={formData}
        errors={formErrors}
      />

      {error && <Text style={styles.errorText}>{error}</Text>}

      <TouchableOpacity
        onPress={handleSubmit}
        style={[styles.button, loading && styles.buttonDisabled]}
        disabled={loading}
        accessibilityLabel="Verify Certificate button"
      >
        {loading ? (
          <ActivityIndicator color="#f9fafb" size="small" />
        ) : (
          <Text style={styles.buttonText}>Verify Certificate</Text>
        )}
      </TouchableOpacity>

      {result && <VerificationResultView result={result} />}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    paddingBottom: 24,
    backgroundColor: "#fef3c7",
    flexGrow: 1
  },
  button: {
    backgroundColor: "#7c3aed",
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 12,
    marginBottom: 12
  },
  buttonDisabled: {
    backgroundColor: "#a78bfa"
  },
  buttonText: {
    color: "#fef3c7",
    fontSize: 17,
    fontWeight: "700",
    textAlign: "center"
  },
  errorText: {
    color: "#b91c1c",
    marginTop: 6,
    fontWeight: "600",
    textAlign: "center"
  }
});

export default VerifyCertificateScreen;
