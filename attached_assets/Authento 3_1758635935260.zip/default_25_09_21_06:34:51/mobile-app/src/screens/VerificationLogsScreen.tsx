import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  TouchableOpacity
} from "react-native";
import { supabase } from "../utils/supabaseClient";
import type { VerificationLog, VerificationStats } from "../types";

const VerificationLogsScreen: React.FC = () => {
  const [logs, setLogs] = useState<VerificationLog[]>([]);
  const [stats, setStats] = useState<VerificationStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;

      if (!token) {
        setError("You must be logged in to view verification logs.");
        setLogs([]);
        setStats(null);
        return;
      }

      const res = await fetch(
        `${process.env.EXPO_PUBLIC_SUPABASE_URL || supabaseUrl()}/functions/v1/verification-stats`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error ?? "Failed to fetch verification stats.");
      }

      const data: VerificationStats = await res.json();
      setStats(data);
      setLogs(data.recent_verifications);
    } catch (err: any) {
      setError(err.message ?? String(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  const supabaseUrl = () => {
    return "https://your-supabase-url.supabase.co"; // Replace with your Supabase URL or env-based
  };

  const renderLogItem = ({ item }: { item: VerificationLog }) => {
    const color =
      item.result === "valid"
        ? "#16a34a"
        : item.result === "fake"
        ? "#dc2626"
        : item.result === "suspicious"
        ? "#ca8a04"
        : "#6b7280";

    return (
      <View style={styles.logItem}>
        <View style={styles.logHeader}>
          <Text style={[styles.logResult, { color }]}>{item.result.toUpperCase()}</Text>
          <Text style={styles.logTimestamp}>{new Date(item.timestamp).toLocaleString()}</Text>
        </View>
        <Text style={styles.logCertificate}>Certificate #: {item.certificate_number}</Text>
        {typeof item.confidence_score === "number" && (
          <Text style={styles.confidence}>Confidence Score: {item.confidence_score.toFixed(2)}%</Text>
        )}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {loading && !refreshing && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#7c3aed" />
        </View>
      )}

      {error && <Text style={styles.errorText}>{error}</Text>}

      {stats && (
        <View style={styles.statsContainer}>
          <Text style={styles.statsText}>Total Verifications: {stats.total_verifications}</Text>
          <Text style={styles.statsText}>Valid: {stats.valid_count}</Text>
          <Text style={styles.statsText}>Fake: {stats.fake_count}</Text>
          <Text style={styles.statsText}>Suspicious: {stats.suspicious_count}</Text>
          <Text style={styles.statsText}>Not Found: {stats.not_found_count}</Text>
          <Text style={styles.statsText}>Success Rate: {stats.success_rate}%</Text>
        </View>
      )}

      <FlatList
        data={logs}
        keyExtractor={(item) => item.id}
        renderItem={renderLogItem}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          !loading && (
            <View style={styles.emptyView}>
              <Text style={styles.emptyText}>No verification logs available</Text>
            </View>
          )
        }
        contentContainerStyle={{ paddingBottom: 24 }}
        accessibilityLabel="Verification Logs List"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 10,
    backgroundColor: "rgba(255,255,255,0.5)"
  },
  errorText: {
    color: "#dc2626",
    marginBottom: 16,
    textAlign: "center"
  },
  statsContainer: {
    marginBottom: 16,
    backgroundColor: "#eef2ff",
    padding: 12,
    borderRadius: 8
  },
  statsText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#3730a3",
    marginBottom: 2
  },
  logItem: {
    marginBottom: 12,
    backgroundColor: "#f9fafb",
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: "#e0e7ff"
  },
  logHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 4
  },
  logResult: {
    fontWeight: "700",
    fontSize: 14
  },
  logTimestamp: {
    fontSize: 12,
    color: "#6b7280"
  },
  logCertificate: {
    fontSize: 14,
    fontWeight: "600",
    color: "#3730a3"
  },
  confidence: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 2
  },
  emptyView: {
    marginTop: 40,
    justifyContent: "center",
    alignItems: "center"
  },
  emptyText: {
    color: "#9ca3af",
    fontSize: 16
  }
});

export default VerificationLogsScreen;
