import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform
} from "react-native";
import { supabase } from "../utils/supabaseClient";

const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  async function handleSignIn() {
    setErrorMsg(null);
    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      if (!data.session) {
        setErrorMsg("No session returned. Please try again.");
      }
    } catch (error: any) {
      setErrorMsg(error.message ?? "An error occurred during sign in.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleSignUp() {
    setErrorMsg(null);
    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.auth.signUp({ email, password });

      if (error) throw error;

      Alert.alert(
        "Sign Up Successful",
        "Please check your email to confirm your account before logging in."
      );
    } catch (error: any) {
      setErrorMsg(error.message ?? "An error occurred during sign up.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.select({ ios: "padding", android: undefined })}
      style={styles.container}
    >
      <View style={styles.wrapper}>
        <Text style={styles.title}>AUTHENTO</Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          autoCapitalize="none"
          keyboardType="email-address"
          autoComplete="email"
          textContentType="emailAddress"
          value={email}
          onChangeText={setEmail}
          editable={!isSubmitting}
          accessibilityLabel="Email input"
        />

        <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry
          textContentType="password"
          value={password}
          onChangeText={setPassword}
          editable={!isSubmitting}
          accessibilityLabel="Password input"
        />

        {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

        {isSubmitting ? (
          <ActivityIndicator size="large" color="#2563eb" />
        ) : (
          <>
            <TouchableOpacity style={styles.button} onPress={handleSignIn} accessibilityLabel="Sign in button">
              <Text style={styles.buttonText}>Sign In</Text>
            </TouchableOpacity>

            <TouchableOpacity style={[styles.button, styles.signUpBtn]} onPress={handleSignUp} accessibilityLabel="Sign up button">
              <Text style={styles.signUpBtnText}>Sign Up</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", backgroundColor: "#f9fafb" },
  wrapper: {
    marginHorizontal: 24,
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 24,
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 2 }
  },
  title: {
    fontSize: 28,
    fontWeight: "900",
    textAlign: "center",
    marginBottom: 24,
    color: "#1e40af"
  },
  input: {
    backgroundColor: "#f3f4f6",
    borderColor: "#d1d5db",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 16,
    fontSize: 16,
    color: "#111827"
  },
  button: {
    backgroundColor: "#2563eb",
    borderRadius: 10,
    paddingVertical: 14,
    marginBottom: 14
  },
  buttonText: {
    fontSize: 17,
    color: "#fff",
    textAlign: "center",
    fontWeight: "700"
  },
  signUpBtn: {
    backgroundColor: "#e0e7ff",
    borderWidth: 1,
    borderColor: "#2563eb"
  },
  signUpBtnText: {
    fontSize: 17,
    color: "#2563eb",
    textAlign: "center",
    fontWeight: "700"
  },
  errorText: {
    color: "#dc2626",
    marginBottom: 12,
    fontWeight: "600",
    textAlign: "center"
  }
});

export default LoginScreen;
