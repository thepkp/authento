import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform
} from "react-native";
import { supabase } from "../utils/supabaseClient";

const UserProfileScreen: React.FC = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<string | undefined>(undefined);
  const [isActive, setIsActive] = useState<boolean | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [passwordError, setPasswordError] = useState<string | null>(null);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    setLoading(true);
    setError(null);
    const session = await supabase.auth.getSession();
    const user = session.data.session?.user;

    if (!user) {
      setError("User not logged in");
      setLoading(false);
      return;
    }

    setEmail(user.email);

    try {
      // Fetch user info from 'users' table
      const { data, error } = await supabase
        .from("users")
        .select("name, role, is_active")
        .eq("id", user.id)
        .single();

      if (error) throw error;
      if (data) {
        setName(data.name ?? "");
        setRole(data.role);
        setIsActive(data.is_active);
      }
    } catch (err: any) {
      setError(err.message ?? "Failed to load user profile");
    } finally {
      setLoading(false);
    }
  };

  const handleProfileUpdate = async () => {
    setUpdating(true);
    setError(null);

    const session = await supabase.auth.getSession();
    const user = session.data.session?.user;

    if (!user) {
      setError("User not logged in");
      setUpdating(false);
      return;
    }

    try {
      const { error } = await supabase.from("users").update({ name }).eq("id", user.id);
      if (error) throw error;
      Alert.alert("Success", "Profile updated");
    } catch (err: any) {
      setError(err.message ?? "Failed to update profile");
    } finally {
      setUpdating(false);
    }
  };

  const validatePassword = () => {
    if (password && password !== passwordConfirm) {
      setPasswordError("Passwords do not match");
      return false;
    }
    if (password && password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      return false;
    }
    setPasswordError(null);
    return true;
  };

  const handleChangePassword = async () => {
    if (!validatePassword()) return;
    if (!password) {
      Alert.alert("Info", "Enter a new password");
      return;
    }

    setUpdating(true);
    setError(null);

    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      Alert.alert("Success", "Password updated");
      setPassword("");
      setPasswordConfirm("");
    } catch (err: any) {
      setError(err.message ?? "Failed to update password");
    } finally {
      setUpdating(false);
    }
  };

  const handleLogout = async () => {
    setLoading(true);
    await supabase.auth.signOut();
    setLoading(false);
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#7c3aed" />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.select({ ios: "padding", android: undefined })}
      style={{ flex: 1 }}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        {error && <Text style={styles.errorText}>{error}</Text>}

        <Text style={styles.label}>Email (readonly)</Text>
        <TextInput style={styles.input} value={email} editable={false} />

        <Text style={styles.label}>Name</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Full Name"
          accessibilityLabel="Name input"
        />

        <Text style={styles.label}>Role</Text>
        <TextInput
          style={[styles.input, { backgroundColor: "#e0e7ff" }]}
          value={role ?? "N/A"}
          editable={false}
        />

        <Text style={styles.label}>Account Status</Text>
        <TextInput
          style={[styles.input, { backgroundColor: "#e0e7ff" }]}
          value={isActive ? "Active" : "Deactivated"}
          editable={false}
        />

        <TouchableOpacity
          onPress={handleProfileUpdate}
          disabled={updating}
          style={[styles.updateBtn, updating && styles.btnDisabled]}
          accessibilityLabel="Update profile button"
        >
          {updating ? (
            <ActivityIndicator color="#ffffff" size="small" />
          ) : (
            <Text style={styles.buttonText}>Update Profile</Text>
          )}
        </TouchableOpacity>

        <View style={styles.divider} />

        <Text style={styles.label}>Change Password</Text>

        <TextInput
          style={styles.input}
          placeholder="New Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          editable={!updating}
          accessibilityLabel="New password input"
        />

        <TextInput
          style={styles.input}
          placeholder="Confirm New Password"
          secureTextEntry
          value={passwordConfirm}
          onChangeText={setPasswordConfirm}
          editable={!updating}
          accessibilityLabel="Confirm new password input"
        />

        {passwordError && <Text style={styles.errorText}>{passwordError}</Text>}

        <TouchableOpacity
          onPress={handleChangePassword}
          disabled={updating}
          style={[styles.updateBtn, updating && styles.btnDisabled]}
          accessibilityLabel="Change password button"
        >
          {updating ? (
            <ActivityIndicator color="#ffffff" size="small" />
          ) : (
            <Text style={styles.buttonText}>Change Password</Text>
          )}
        </TouchableOpacity>

        <View style={styles.divider} />

        <Button title="Logout" color="#dc2626" onPress={handleLogout} accessibilityLabel="Logout button" />
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: "#f9fafb",
    flexGrow: 1
  },
  label: {
    fontWeight: "700",
    fontSize: 15,
    marginBottom: 8,
    color: "#1e40af"
  },
  input: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 8,
    backgroundColor: "#fff",
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 16,
    fontSize: 16,
    color: "#374151"
  },
  updateBtn: {
    backgroundColor: "#2563eb",
    paddingVertical: 14,
    borderRadius: 10,
    marginBottom: 16
  },
  btnDisabled: {
    backgroundColor: "#b3c7f9"
  },
  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center"
  },
  errorText: {
    color: "#b91c1c",
    marginBottom: 12,
    fontWeight: "600"
  },
  divider: {
    height: 1,
    backgroundColor: "#e5e7eb",
    marginVertical: 16
  },
  centered: { flex: 1, justifyContent: "center", alignItems: "center" }
});

export default UserProfileScreen;
